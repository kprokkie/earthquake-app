{

    let result = {
        a: {
            b: 8,
            d: {
                c: 4
            }
        },
        p: 9

    };

    let obj1 = {
        a: {
            b: 8,
        },
        p: 9
    };

    let obj2 = {
        a: {
            d: {
                c: 4
            }
        }
    };

    // console.log(Object.assign({}, obj1, obj2));
    // console.log({ ...obj1, ...obj2 });
    // console.log(obj1);

    function deepCopy(obj1, obj2) {

    }

    console.log(deepCopy(obj1, obj2));
}