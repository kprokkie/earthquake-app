function noisy(f) {
    return (...args) => {
        //console.log("calling with", args);
        let result = f(...args);
        //console.log("called with", args, ", returned", result);
        return result;
    };
}
// noisy(Math.min)(3, 2, 1);
// → calling with [3, 2, 1]
// → called with [3, 2, 1] , returned 1

let getMin = noisy(Math.min);
console.log(getMin(1, 2, 3));

let getMax = noisy(Math.max);
console.log(getMax(1, 2, 3));

let getLog = noisy(console.log);
console.log(getLog(1, 2, 3));