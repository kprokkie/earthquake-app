let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// M1
// let filterArr = arr.filter((x) => x % 2 === 0);
// console.log(filterArr, arr);


function condition(x) {
    return x % 2 === 0;
}

// M2
// let filterArr = arr.filter(condition);
// console.log(filterArr, arr);

Array.prototype.newFilter = function (cb) {
    console.log(this, cb);
    return this.filter(cb);

}

let filterArr = arr.newFilter(condition);
console.log(filterArr, arr);

function isInRange(value) {
    if (typeof value !== 'number') {
        return false;
    }
    return value >= this.lower && value <= this.upper;
}

let data = [10, 20, "30", 1, 5, 'JavaScript filter', undefined, 'example'];

let range = {
    lower: 1,
    upper: 10
};

let numberInRange = data.filter(isInRange, range);

console.log(numberInRange); // [10, 1, 5]

// custom filter
function filter(array, test) {
    let passed = [];
    for (let element of array) {
        if (test(element)) {
            passed.push(element);
        }
    }
    return passed;
}

// console.log(filter(SCRIPTS, script => script.living));
// → [{name: "Adlam", …}, …]

// custom map
function map(array, transform) {
    let mapped = [];
    for (let element of array) {
        mapped.push(transform(element));
    }
    return mapped;
}

// let rtlScripts = SCRIPTS.filter(s => s.direction == "rtl");
// console.log(map(rtlScripts, s => s.name));
// → ["Adlam", "Arabic", "Imperial Aramaic", …]

// custom reduce
function reduce(array, combine, start) {
    let current = start;
    for (let element of array) {
        current = combine(current, element);
    }
    return current;
}

console.log(reduce([1, 2, 3, 4], (a, b) => a + b, 0));
// → 10

// every
function every(array, test) {
    // Your code here.
    for (let element of array) {
        if(!test(element))  return  false;
    }
    return true;
}

console.log(every([1, 3, 5], n => n < 10));
// → true
console.log(every([2, 4, 16], n => n < 10));
// → false
console.log(every([], n => n < 10));
  // → true
