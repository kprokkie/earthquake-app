{
    // Regular expressions are objects that represent patterns in strings. They use their own language to express these patterns.

    // /abc/	A sequence of characters
    // /[abc]/	Any character from a set of characters
    // /[^abc]/	Any character not in a set of characters
    // /[0-9]/	Any character in a range of characters
    // /x+/	One or more occurrences of the pattern x
    // /x+?/	One or more occurrences, nongreedy
    // /x*/	Zero or more occurrences
    // /x?/	Zero or one occurrence
    // /x{2,4}/	Two to four occurrences
    // /(abc)/	A group
    // /a|b|c/	Any one of several patterns
    // /\d/	Any digit character
    // /\w/	An alphanumeric character (“word character”)
    // /\s/	Any whitespace character
    // /./	Any character except newlines
    // /\b/	A word boundary
    // /^/	Start of input
    // /$/	End of input

    let dateTime1 = /\d\d-\d\d-\d\d\d\d \d\d:\d\d/;
    console.log(dateTime1.test("01-30-2003 15:20"));
    // → true
    console.log(dateTime1.test("30-jan-2003 15:20"));
    // → false

    let dateTime2 = /\d{1,2}-\d{1,2}-\d{4} \d{1,2}:\d{2}/;
    console.log(dateTime2.test("1-30-2003 8:45"));
    // → true
}

{
    let match = /\d+/.exec("one two three 1000 100000 100");
    console.log(match);
    // → ["100"]
    console.log(match.index);
    // → 8

    console.log("one two 100".match(/\d+/));
    // → ["100"]

    let quotedText = /'([^']*)'/;
    console.log(quotedText.exec("she said 'hello'"));
    // → ["'hello'", "hello"]
}