{
    let list = {
        value: 1,
        rest: {
            value: 2,
            rest: {
                value: 3,
                rest: null
            }
        }
    };

    function arrayToList(arr) {
        let list = null;
        for (let i = arr.length - 1; i >= 0; i--) {
            list = {
                value: arr[i],
                rest: list
            }
        }
        return list;
    }

    function arrayToListRecursive(arr) {
        let list = null;
        let idx = 0;

        function helper(value) {
            if (!value) return null;

            list = {
                value: value,
                rest: helper(arr[++idx])
            }

            return list;
        }

        helper(arr[idx]);
        return list;
    }

    function listToArray(list) {
        let arr = [];
        for (let node = list; node; node = node.rest) {
            arr.push(node.value);
        }
        return arr;
    }

    // Your code here.
    console.log(arrayToList([10, 20, 30]));
    console.log(arrayToListRecursive([10, 20, 30]));
    // → {value: 10, rest: {value: 20, rest: null}}
    console.log(listToArray(arrayToList([10, 20, 30])));
    // // → [10, 20, 30]
    // console.log(prepend(10, prepend(20, null)));
    // // → {value: 10, rest: {value: 20, rest: null}}
    // console.log(nth(arrayToList([10, 20, 30]), 1));
    // → 20

}

