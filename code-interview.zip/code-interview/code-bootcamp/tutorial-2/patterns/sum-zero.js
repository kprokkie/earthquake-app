// Multiple Pointer Pattern

// [-4,-3,-2,-1,0,1,2,3,10] 
// [-3,3]