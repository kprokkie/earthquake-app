function solveMeFirst(a, b) {
  return a + b;
}

console.log(solveMeFirst(2, 3));