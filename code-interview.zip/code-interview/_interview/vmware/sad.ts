// Complete the getAppNamesWithFeature function below.
function getAppNamesWithFeature(apps, platforms, featureName) {

    let hash = {};
    for (let i = 0; i < platforms.length; i++) {
        if (platforms[i].features.includes(featureName))
            hash[platforms[i].name] = platforms[i].name;
    }

    let appsName = [];
    for (let j = 0; j < apps.length; j++) {
        if (hash[apps[j].platform]) {
            console.log(hash[apps[j].platform]);
            console.log(apps[j].name);
            appsName.push(apps[j].name);
        }
    }
    return appsName;
}

let apps = [{ "name": "InstaPic", "platform": "ANDROID" }, { "name": "MadBirds", "platform": "IOS" }, { "name": "NetMovies", "platform": "ANDROID" }, { "name": "WeTalk", "platform": "WINDOWS" }];
let platforms = [{ "name": "IOS", "features": ["APP_MANAGEMENT", "FIREWALL"] }, { "name": "ANDROID", "features": ["FIREWALL", "KIOSK_MODE"] }, { "name": "WINDOWS", "features": ["KIOSK_MODE", "REMOTE_ACCESS"] }];
let featureName = 'KIOSK_MODE';

console.log(getAppNamesWithFeature(apps, platforms, featureName));

let fruits = [];

fruits.push("Kiwi");

console.log(fruits);