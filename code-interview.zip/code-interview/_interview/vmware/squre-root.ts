var mySqrt = function (x) {
    if (x === 0 || x === 1) return x;

    let left = 0;
    let right = x;
    let mid = Math.floor(x / 2);

    console.log('------------------');
    console.log('left', left);
    console.log('right', right);
    console.log('mid', mid);

    while (right - left > 1) {
        if (mid * mid <= x)
            left = mid;
        else
            right = mid;
        mid = Math.floor((left + right) / 2);

        console.log('------------------');
        console.log('left', left);
        console.log('right', right);
        console.log('mid', mid);
    }

    return left;
};

console.log(mySqrt(10));