const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const arr1 = [4, 5, 6, 7, 8, 9, 10, 1, 2, 3];

function getIndex(arr, key) {
    let l = 0;
    let r = arr.length - 1;
    // return binarySearch(arr, key, l, r);
    return pivotBinarySearch(arr, key, l, r);
}

function getPivot(arr, l, r) {

    if (r < l) return -1;
    if (l === r) return l;

    let m = Math.floor((l + r) / 2);

    if (m < r && arr[m] > arr[m + 1]) return m;
    if (m > l && arr[m] < arr[m - 1]) return m - 1;

    if (arr[l] >= arr[m]) return getPivot(arr, l, m - 1);
    else return getPivot(arr, m + 1, r);
}

function pivotBinarySearch(arr, key, l, r) {
    let pivot = getPivot(arr, l, r);

    // normal
    if (pivot === -1) return binarySearch(arr, key, l, r);

    if (arr[pivot] === key) return pivot;

    if (arr[0] <= key) return binarySearch(arr, key, 0, pivot - 1);
    else return binarySearch(arr, key, pivot + 1, r);

}  

function binarySearch(arr, key, l, r) {

    if (r < l) return -1;
    let m = Math.floor((l + r) / 2);

    if (arr[m] === key) return m;

    if (arr[m] > key) return binarySearch(arr, key, l, m - 1);
    else return binarySearch(arr, key, m + 1, r);
}

console.log(getIndex(arr, 7));
console.log(getIndex(arr, 3));

console.log(getIndex(arr1, 10)); // pivot is key
console.log(getIndex(arr1, 7));
console.log(getIndex(arr1, 3));