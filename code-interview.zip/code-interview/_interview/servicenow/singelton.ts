function Car(name, model) {
    this.name = name;
    this.model = model;
}


let singleObj = (function () {
    let obj;

    function createObj() {
        console.log('Created');
        return new Car('Mazda', 'CX5');
    }

    return {
        getInstance: function () {
            if (!obj) obj = createObj();
            return obj;
        }
    }
})();

console.log(singleObj.getInstance());
console.log(singleObj.getInstance());
console.log(singleObj.getInstance());