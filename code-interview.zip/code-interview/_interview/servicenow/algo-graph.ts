console.log('Hello World!');

const data = [{
    x: 250,
    y: 150,
    label: '5.62'
}
];

function reduceLabel(data, labelH, labelW) {
    let result = [];
    let basePoint = data[0];
    result.push(basePoint);

    for (let i = 0; i < data.length; i++) {
        if (data[i].y < basePoint.y + labelH ||
            data[i].y > basePoint.y - labelH) {
            result.push(data[i]);
            basePoint = data[i];
        } else {
            if (basePoint.x < data[i].x - labelW) {
                result.push(data[i]);
                basePoint = data[i];
            }
        }
    }

    return result;
}

reduceLabel(data, 10, 50);