// let greeting = (function () {
//     let msg = 'Hello';

//     let getMessage = function () {
//         return msg;
//     }

//     return {
//         getMsg: getMessage
//     }

// })();

// console.log(greeting.getMsg());

// function setUpCounter(val) {
//     return function counter () {
//         return val++;
//     }
// }

// let counter1 = setUpCounter(0);
// let counter2 = setUpCounter(10);

// console.log(counter1());
// console.log(counter1());
// console.log(counter2());
// console.log(counter1());
// console.log(counter2());

function isCheckArr(obj) {
    return obj.constructor === Array;
}

console.log(isCheckArr([1,2,1]));
console.log(isCheckArr('string'));

let a = 5;
let b = 3;

a = a + b;
b = a - b;
a = a - b;

console.log(a);
console.log(b);