const _ = require('lodash');

function sayHello() {
  console.log('Hello, World');
}

// _.times(5, sayHello);



// Your previous Plain Text content is preserved below:

// [0,1,2,3,4,5,6,7]
// array - input - [4,5,6,7,0,1,2]
//  Please find a number 0
 
// function findNumber(arr, number) {
//   let i;
//   for (i = 0; i < arr.length; i++) {
//     if (arr[i] === number) {
//       break;
//     }
//   }
//   return i;
// }

// findNumber([4,5,6,7,0,1,2], 0); // 


function helper(arr, l, r, num) {

    if (r < l) return -1;
  
    let m = Math.floor((l + r) /2);
  // console.log(m);
    
    if (num === arr[m])
      return m;
    
    if (num > arr[m]) 
      return helper(arr, m+1, r, num);
    else
     return helper(arr, l, m -1, num);

}

function findNumberOp (arr, num) {
  return helper(arr, 0, arr.length - 1, num);
}

let index = findNumberOp([], 0);
console.log(index);

