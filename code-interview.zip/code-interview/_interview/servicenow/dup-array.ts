const arr = [1, 1, 2, 3, 3, 5];

// using same space
function dedupArr(arr) {
    let len = arr.length;
    let j = 0;
    for (let i = 1; i < len;) {
        if (arr[j] === arr[i]) {
            i++
        } else {
            j++; 
            arr[j] = arr[i];
        }
    }
    arr.length = j + 1;
    return arr;
}

// console.log(dedupArr(arr));

function dedupArrHash(arr) {
    let res = [];
    let hash = {};

    for (let i = 0; i < arr.length; i++) {
        if (!hash[arr[i]]) {
            hash[arr[i]] = arr[i]; 
            res.push(arr[i]);
        }
    }
    console.log(hash);
    return res;
}

console.log(dedupArrHash(arr));