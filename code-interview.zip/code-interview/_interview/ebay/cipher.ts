/*

A "cipher match" is a string that maps 1:1 to another string. So, for example:
ABCDA -> JKLMJ
is a cipher match. So is:
ABBA -> XYYX
However, the following is NOT a cipher match:
ABCD -> JKLL
Because "C" and "D" cannot both map to "L."
Given an input list of strings, find all pairs of cipher matches in the input list.
input: ["abcd", "abcd", "gthw", "hggh", "wxyz", "ikki", "iaaa", "bsbdb", "qwer", .....]

// ABCDA -> JKLMJ

A: J
B: K
C: L
D: M

*/


// ABCD => ABCC
// ABCC => ABCD

function match(s1, s2) {
    
    if (s1 === s2) return true;
    if (s1.length === s2.length) return false;

    let map1 = new Map();
    let map2 = new Map();

  
    for (let i = 0; i <= s1.length; i++) {
        if (map1.has(s1[i])) {
          if (map1.get(s1[i]) !== s2[i]) return false;
        } else {
          map1.set(s1[i], s2[i]); // A: J
        }
      
       if (map2.has(s2[i])) {
          if (map2.get(s2[i]) !== s1[i]) return false;
        } else {
          map2.set(s2[i], s1[i]); // A: J
        }
    }
  
   return true;
}

// //
// input: ["abcd", "abcd", "gthw", "hggh", "wxyz", "ikki", "iaaa", "bsbdb", "qwer", .....]'

// abcd = 1_2_3_4_22
// abba = 1221
// hggh = 1221

// input: ["3", 56, 223, "3", ....]

function cipher (arr) {
  
let pair  = 0;
 for (let i = 0; i < arr.length; i++) {
    for (let j = i + 1; j < arr.length; j++) {
      if (match(arr[i], arr[j]))
        pair++;
    }
  }
  
  
  return pair;
}




const _ = require('lodash');

function sayHello() {
  console.log('Hello, World');
}

_.times(5, sayHello);
