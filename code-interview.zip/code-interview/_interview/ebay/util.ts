class util {

    value;

    static sum(...params) {
        this.value = params.reduce((a, c) => a + c, this.value || 0);
        return this;
    }

    static mul(...params) {
        this.value = params.reduce((a, c) => a * c, this.value || 1);
        return this;
    }

    static end() {
        let result = this.value;
        this.value = null;
        return result;
    }

}

console.log(util.sum(4, 5).end());
console.log(util.sum(4, 5).sum(10, 20).end());
console.log(util.mul(4, 5).sum(10).end());
console.log(util.end());



