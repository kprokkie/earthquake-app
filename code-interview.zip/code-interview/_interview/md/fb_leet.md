> Facebook | Onsite | Buffer
> Facebook Interview
> Facebook | Onsite | Tree Iterator - `DONE`
https://leetcode.com/problems/binary-search-tree-iterator/
https://leetcode.com/problems/convert-binary-search-tree-to-sorted-doubly-linked-list/

> Facebook | Sorted Iterator
> Facebook | Balance Parentheses - `DONE`
https://leetcode.com/problems/minimum-remove-to-make-valid-parentheses/
https://leetcode.com/problems/minimum-add-to-make-parentheses-valid/
https://leetcode.com/problems/remove-invalid-parentheses/

> Facebook | Onsite | Spaced permutations
> Facebook Telephonic Interview
https://leetcode.com/problems/integer-to-english-words/
https://leetcode.com/problems/next-greater-node-in-linked-list/

> Facebook | Phone Screen | Cut Wood
https://leetcode.com/problems/koko-eating-bananas/

> Facebook | Phone Screen | Palindromic Subsequences
Given a string s, return all palindromic subsequences of s. Example 1:
Input: "abac" Output: ["a", "b", "c", "aa", "aba"]
https://www.geeksforgeeks.org/count-palindromic-subsequence-given-string/
https://leetcode.com/problems/count-different-palindromic-subsequences/
https://www.geeksforgeeks.org/find-number-distinct-palindromic-sub-strings-given-string/

> Facebook | Onsite | Task Scheduler
https://leetcode.com/problems/task-scheduler/

> Facebook Phone Screen
https://leetcode.com/problems/integer-to-english-words/

> Facebook | Phone Screen | Implement clearAllTimeout - `DONE`
Implement EventEmitter
Implement clearAllTimeout

> Facebook | Phone Screen | Implement EventEmitter - `DONE`
https://leetcode.com/discuss/interview-question/331978/Facebook-or-Phone-Screen-or-Implement-EventEmitter

> Facebook Phone screenings - `DONE`
https://leetcode.com/problems/best-time-to-buy-and-sell-stock/
https://leetcode.com/problems/find-largest-value-in-each-tree-row/

https://leetcode.com/problems/add-strings/
https://leetcode.com/problems/combination-sum/
https://leetcode.com/problems/subarray-sum-equals-k/ 

> Facebook | Onsite | Schedule of Tasks
https://leetcode.com/problems/merge-intervals/

> Facebook | Phone Screen | Sum to 100
https://leetcode.com/playground/HV2jmPMU

> Facebook | Phone | Data engineer
find the average length of word in sentence
Validate the ip address
for a list array=[['D'],['A','B'],['A','C'],['C','A']] find the number of followers

> Facebook | Onsite | Matrix Antidiagonal Traverse
https://leetcode.com/problems/diagonal-traverse/

> Facebook | Phone | HTML Snippet
> Facebook System design
Design keyword search in FB Posts?
What is the best approach for this question?

> Facebook Phone screen
https://leetcode.com/problems/minimum-depth-of-binary-tree/
Question 1: Min Depth of any leaf node (I solved by BFS)
Question 2: Solve Question 1 using DFS

> facebook phone screen
https://leetcode.com/problems/serialize-and-deserialize-binary-tree/
https://leetcode.com/problems/binary-tree-right-side-view/
https://leetcode.com/problems/restore-ip-addresses/


> Facebook | Leftmost column index of 1
https://leetcode.com/problems/leftmost-column-with-at-least-a-one/ (premium)
https://leetcode.com/problems/search-a-2d-matrix-ii

> Facebook | Phone | Intern
https://leetcode.com/problems/merge-sorted-array/
https://leetcode.com/problems/maximum-swap/

Dot product of sparse vectors
https://leetcode.com/problems/subarray-sum-equals-k/

> Facebook | Onsite | Generate random max index

> Facebook | Onsite | Generate patterns
https://leetcode.com/problems/letter-combinations-of-a-phone-number/description/

Interview Exp:

> Facebook Onsite 2020
Question 1 : https://www.***.org/find-index-maximum-occurring-element-equal-probability/ O(1) space
Question 2 : https://leetcode.com/problems/range-sum-of-bst/

Question 1 : https://www.***.org/find-closest-element-binary-search-tree/
Question 2 : https://leetcode.com/problems/insert-delete-getrandom-o1/
 Calculate tax if Salary and Tax Brackets are given as list in the form
[ [10000, 0.3],[20000, 0.2], [30000, 0.1], [null, .1]]
null being rest of the salary

> Facebook Phone Interview
You can use sliding window, and do it in O(n) without using extra space, given your array only has non-negatives. Sliding window won't work for negative values. Here is the solution using Kadane's algorithm which takes O(n) time and takes O(1) space works if list has negative numbers present
Given a list of positive numbers and a target integer k, write a function to check if the array has a continuous subarray which sums to k
https://leetcode.com/problems/continuous-subarray-sum/

> Facebook Telephonic Round
Verify Alien Dictionary https://leetcode.com/problems/verifying-an-alien-dictionary/
Alien Dictionary https://leetcode.com/problems/alien-dictionary/

> Facebook | Intern | Seattle [Reject]
https://leetcode.com/problems/binary-tree-paths
https://leetcode.com/problems/minimum-window-substring


> Facebook onsite interview experience 2019
Round 1:

Schedule of Tasks
https://leetcode.com/problems/binary-tree-maximum-path-sum
https://leetcode.com/problems/maximum-subarray
Round 2:

https://leetcode.com/problems/custom-sort-string
https://leetcode.com/problems/read-n-characters-given-read4 (premium)
Round 3 [System design]:

Design Instagram
Round 4:

https://leetcode.com/problems/remove-invalid-parentheses
Round 5 [System design]:

Design keyword search in FB Posts

> Facebook | E4 | Mar 2020
Question 0. Similar strings ("face", "eacf") returns true if only 2 positions in the strings are swapped. Here 'f' and 'e' are swapped in the example.
Question 1. Number Of connected components in a Graph,
Question 2 (Behavior interview/ coding). Is there a way to reach (0,0) from a mXn matrix to (m-1,n-1) position and give the path.
Question 3 System Design : Design a Content publishing site with privacy restrictions.
Questions 4. https://leetcode.com/problems/simplify-path/
Question 5. n-ary Tree with each node having a boolean flag. Traverse all the nodes with only boolean flag = True. Return the total distance traveled from root to all those nodes.

> Two Facebook intern interviews
1st round:
First Bad Version: https://leetcode.com/problems/first-bad-version/
Alien Dictionary: https://leetcode.com/problems/alien-dictionary/
2nd round:
Search in Rotated Sorted Array : https://leetcode.com/problems/search-in-rotated-sorted-array/
Search in Rotated Sorted Array II: https://leetcode.com/problems/search-in-rotated-sorted-array-ii/

> Facebook | E4 | Seattle [Reject]
Round 1:

37. Sudoku Solver
Round 2:

301. Remove Invalid Parentheses return just 1 possible solution
560. Subarray Sum Equals K
Round 3:

System design. Design a leetcode contest, leadership board system - FAIL
Round 4:

Behavioral questions
102. Binary Tree Level Order Traversal 10 min question. Kind of a stress test.
Round 5:

329. Longest Increasing Path in a Matrix

> Facebook | SWE | Apr 2019
https://leetcode.com/problems/maximum-subarray
https://leetcode.com/problems/valid-parentheses
Big O for both questions

https://leetcode.com/problems/move-zeroes
was asked to return the count of zeroes after moving 0's to the end
was asked to write down the steps after every iteration
Calculate tax if Salary and Tax Brackets are given as list in the form
[ [10000, 0.3],[20000, 0.2], [30000, 0.1], [null, .1]]
null being rest of the salary
Big O for both questions

https://leetcode.com/problems/palindrome-permutation
Input char array consistes of 'W' and 'H' for week day and holiday respectively, and an
int n. We can change 'W' to 'H' n times and return the longest continoust subarray consisting 'H'
Variant of https://leetcode.com/problems/max-consecutive-ones-iii

here are music providers like spotify, apple music etc. Design a service for these providers to display top 10 songs played by each user. Was aked to write ER tables and API's.

Given a BST and two values p, q -> return an int which is sum of all the values between p and q inclusively
https://leetcode.com/problems/range-sum-of-bst

https://blog.taxact.com/how-tax-brackets-work/

> Facebook Interview February 2018

Reverse a string in place. Modification 1, Reverse it without reversing words, Modification 2, Remove all trailing spaces in front or extra spaces in between a string, and a tuple (reversed string, length).
https://leetcode.com/problems/meeting-scheduler/

> Facebook | SWE | Menlo Park
https://leetcode.com/problems/merge-intervals

https://leetcode.com/problems/valid-number
https://leetcode.com/problems/verifying-an-alien-dictionary

Design a system like Hacker Rank for a programming contest and their ranking.

https://leetcode.com/problems/serialize-and-deserialize-binary-tree
https://leetcode.com/problems/exclusive-time-of-functions

> Facebook Phone Round 2020
https://leetcode.com/problems/remove-all-adjacent-duplicates-in-string/
 https://leetcode.com/problems/valid-palindrome/

 >Facebook | E4 Android | California [Offer]
 https://leetcode.com/problems/add-strings
https://leetcode.com/problems/valid-palindrome-ii

https://leetcode.com/problems/best-time-to-buy-and-sell-stock
follow up:
https://leetcode.com/problems/best-time-to-buy-and-sell-stock-iii
https://leetcode.com/problems/best-time-to-buy-and-sell-stock-iv

Design instagram client side.
https://leetcode.com/problems/add-and-search-word-data-structure-design
https://leetcode.com/problems/merge-sorted-array

https://leetcode.com/problems/maximum-subarray
https://leetcode.com/problems/serialize-and-deserialize-binary-tree without using preorder, inorder, or postorder

> Facebook | Intern 1st Interview [Pass
Serialize and Deserialize a Binary Tree
Lowest Common Ansestor
Smallest Subtree With Deepest Nodes


>Facebook | EE | London | Onsite [Rejected]
https://leetcode.com/problems/add-binary/
https://leetcode.com/problems/product-of-array-except-self/
https://leetcode.com/problems/verifying-an-alien-dictionary/
https://leetcode.com/discuss/interview-question/432086/Facebook-or-Phone-Screen-or-Task-Scheduler/394783

> Facebook | E4 | London | May 2020 [Rejected]
https://leetcode.com/problems/valid-palindrome-ii/
https://leetcode.com/problems/kth-smallest-element-in-a-bst/

https://leetcode.com/problems/k-closest-points-to-origin/
Randomly generate mines on a grid

> Facebook | SE | London | July 2019 [Rejected]
https://leetcode.com/problems/serialize-and-deserialize-binary-tree
 https://leetcode.com/problems/valid-palindrome
 https://leetcode.com/problems/powx-n/
 https://leetcode.com/problems/subarray-sum-equals-k
 https://leetcode.com/problems/find-all-anagrams-in-a-string
 https://leetcode.com/problems/is-graph-bipartite 

 >Facebook Graduate London [Reject]
 207. Course Schedule https://leetcode.com/problems/course-schedule/
986. Interval List Intersections https://leetcode.com/problems/interval-list-intersections/

Facebook | Software Engineering Intern 2017
>  Given two binary search trees how do we merge everything so it prints inorder



Facebook | E5 | Seattle | Virtual Onsite [Pending]
>  https://leetcode.com/discuss/interview-question/560984/Facebook-or-Phone-or-Product-of-Array-Except-Self-and-Divide-Integers 




