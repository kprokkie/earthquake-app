JS

Basic:

> this & its behaviour
> closure
> protoypical inheritence
> var, let & const
> DOM tree
> map, forEach, reduce
> apply, call
> difference btw array & object
> Advantages ES6 Maps over Objects
> ES6 over arrays
> === vs ==
> Event Delegation or Propogation or Bubbling
> async
> Debounce & Throttling
> DOM tree manipulation
> javascript performance functions
> timeouts, prototypes, the DOM
> javascript collections
> tree traversal 
> differences between queue and stack
> event propagation
> time complexity to traverse the balanced binary tree
> specific DOM API's
> Optimize the given function
> DOM, trees, maps/set/array/object and string

Behavioural:
> Why Facebook? 
> Why Front End? 
> Tell about a project you had and how you solved it? 
> Tell about a conflict you had at work and how you dealt with it?

Implement: 
> `Deeply Flatten an Array (Iterative & Recursive)`
> `Given an array, return it's flattened structure (skip objects) `
> `Flatten array. This array can have multiple types: {}, [], "", undefined, null, 123 are all valid types inside the array`
> `Create an Emmitter or Emitter Class or Event Emitter Class`
> Implement an Observable
> ES6 Promisies
> Observer Pattern
> `Given 2 identical DOM trees (but not equal) and one element of the first DOM tree, how would you find this element in the second DOM tree? ` 
> `Given two identical DOM tree structures, A and B, and a node from A, find the corresponding node in B.`
> `Given a node from a DOM tree find the node in the same position from an identical DOM tree. ` 
> `Given a tree with specific nodes to visit, traverse another tree with the same structure and visit the nodes in same positions. ` 
> Implement a simple store class with set(Node, value), get(Node) and has(Node) methods, which store a given Nodes with corresponding values. 
> Calendar challenge (as the others have said there's a challenge) 
> Build a layout for a calendar where events added on the calendar that collide in time can't visually collide but should take same width with the events that they collide in time with.
> Poll Widget question (just know your positioning, relative, static etc know the differences inside out). You might want to know specificity as well.  
> `Debounce: write a function that gets called on every key down but calls the server when the user stops typing for 400ms.`
> array search/mutation algorithms 
> `Given an input array and another array that describes a new index for each element, mutate the input array so that each element ends up in their new index. Discuss the runtime of the algorithm and how you can be sure there won't be any infinite loops` 
> `How many times would `addEventListener('scroll', handleScroll);` run as the user looks at their News Feed? And what would be user experience if the `handleScroll` function takes 100ms to execute. ` 
> `how could you implement debouncing? Say you wanted the `handleScroll` function to be called only after 200ms has passed between scroll events`
> `write a function that takes an array as input that can contain both ints and more arrays (which can also contain an array or int) and return the flattened array. [1,[2,[[3, 4],5],6]] => [1, 2, 3, 4, 5, 6]` 
> Implement a square root function.
> array data manipulation
> `Design and code a Pinterest style UI, where cards stack top/down and scroll infinitely.`
> `Implement a Promise from scratch.`
> `Implement an event emitter from scratch.`
> `Implement a throttle and/or debounce function.`
> `Implement an image carousel.`
> `Implement a 1-5 star rating system.`
> `Promisify a function`



HTML/CSS:
> `Given a picture, how would you hide/show a child picture on hovering on this parent? `
> `How would you ensure clicking on this picture would go to a specific link? `
> `How would you ensure the child is positioned in the top right of the parent picture? `
> `show how you would create an image that would display another image (aligned to the bottom, right) when the user hovers over the image. ex. The Facebook "edit profile picture" icon  `
> `Implement AnimateRight `
> `Given a large image and a small image how would you position the small image over the large image on hover. Also each of the images should go to different URLs.`

> ALGO

