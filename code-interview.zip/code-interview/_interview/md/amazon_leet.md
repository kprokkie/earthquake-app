> Amazon Front
https://leetcode.com/discuss/interview-question?currentPage=2&orderBy=newest_to_oldest&query=amazon%20front
https://leetcode.com/discuss/interview-experience?currentPage=1&orderBy=newest_to_oldest&query=amazon%20front

Experience: ------------------------------------------------------------------------------------------------
https://leetcode.com/discuss/interview-experience/679124/Amazon-or-Front-End-L4-or-Seattle-or-Apr-2020-Offer

Process:
Technical phone screen:
LP + JavaScript Questions + Logical Problem(JS Array based question)

Onsite (5 rounds, each an hour):

LP + JavaScript Tree based question(Related to DOM)
Complete Behavioral round
LP + System Design: System design of an app with focus on Client-side design.
LP and a JS problem(JavaScript + HTML + CSS): Common DOM manipulation question.
Similar to round 4: LP and a JS problem[Focus on Ajax request(XHR)]

https://leetcode.com/discuss/interview-experience/533737/OnSite-Amazon-front-end-Virtual

DS / algo - for the given binary tree find the distance or number of hop required to move from one node to another.
Desgin question - Design vedio upload / watch (view) / tag / post comment / share web application
JS/HTML - Desgin star rating
Manager round - All question realted to behavioural, focused on Amazon 14 principle.



https://leetcode.com/discuss/interview-experience/336727/Amazon-or-Front-End-Engineer-or-Seattle-or-July-2019-Reject

Tell me about a project you worked on?
Why would a website minify their source code?
What is the difference between MyObject.foo and MyObject.prototype.foo?
A series of CSS selector questions that built off the last (like what does .my-div select? Okay now what does .my-div p select? etc)
Create a basic Car object with functions accelerate and deccelerate. Now create two cars with separate starting speeds and perform this set of speed changes on them.
Write HTML, CSS, and JS to perform the following:
There is a button on a page with text inside that says 'Clicked {#} times' with the number changing each time the button has been clicked.
Follow up: Now each time the button is clicked, spawn a new button with its own counter, and the same functionality.


Algo: -----------------------------------------------------------------------------------------------------
https://leetcode.com/problems/word-break/
implement typeahead search as ds/algo
find the distance or number of hop required to move from one node to another.
Detect words in a string - Used recursion, simple enough
traverse the entire DOM for either an "element", "class" or "id"

FEE: ----------------------------------------------------------------------------------------------

Build a small application & widget from scratch using HTML, CSS & vanilla JavaScript.
Widget is a star rating component utilizing five stars.
Stars should be grey and change to gold when the user selects one or hovers over it.
All stars rated lower than the selected or hovered star should also change when selected/hovered.
Stars should be displayed horizontally.
Star did not need to be (visually) a star... could just be an element. I made mine a circle.
This was for the AWS team.

Create a function that will handle language change for every texts in the dom (e.g english to spanish) when clicked on a button.
Had to ask clarifying questions and expectations and etc to narrow down the scope
use vanilla js, html, css only.

Prepare to implement common classes (Promise, EvenEmitter, Observable etc), util functions (debounce, throttle, retry etc) and dom api (like getElementsByClassName etc) in pure js.
What is difference between the block and inline elements?
What is difference between Reflow and Repaint?
How can you add a span element inside a div element using web APIs ?
What are CSS preprocessors SASS/LESS used for?
How event loop handles micro and macro tasks?
What is the difference between Unit testing and Integration testing?
How do you identify memory leaks in browser? (Interviewer told me that is an Open ended question)
Final Question was how will you find all the prime numbers up to n? Optimize the prime number?

 basic tabable ui which is responsive, fires events, accessible, optimized, localized etc.

 Recreate an Amazon widget in vanilla JavaScript and connect it to a back-end end-point
This test essentially tested you for the following things:
Async requests (How promises work and stuff), using old school XHR techniques
Pushes you to do async/await and thenable styles
Creating re-usable HTML elements and using JavaScript to invoke similar (with a slight variation to each depending on id) action
Best practices for network requests, eg. using a loader state, error state, success state
Writing too much CSS or HTML will get you deductions
DOM manipulation

The interviewer showed me some simple design that was created in a webpage, and stated 'Assume you are given an API that uses an AJAX call to return a list of labels. Using HTML/CSS/JS format them as seen on the screen.'

Now I want to add a button within each cell to remove a label from the screen
Now I want to be able sort the labels, how would I do that? How is this effected by the removing of the labels?
You now notice that what is being returned from the AJAX call is not the same as before, what steps do you take to solve the problem?
I asked if I could use React, and she seemed okay with it, as long as I could explain what I would have to do if I wasn't using React. I ended up using a somewhat blend between normal JS and React, as it seemed she did not entirely understand the React code. Similarly, it seemed as if the interviewer was typing everything I had written on the whiteboard word-for-word.

Design a class to implement a list which contains hot selling items from a catalog of given items per seller.
Basic questions on types of HTTP response, how to handle browser inconsistencies, favorite es6 feature and day to day activities routine in my current job
Design an Accordion.Design a carousel.

SD: ---------------------------------------------------------------------------------------------------------
how system is design for like amazon order syste, how do they deliver prime order so fast, how the cart is designed ? etc .. where can i find some blogs or good resources for system design like above scenarios

If you were to design a web app that uses flash cards to help people learn a foreign language. The flashcard front side shows a word in the first language of the user, and when being hovered/clicked on, the flash card will flip and show the word in a foreign language. How would you go about designing this? Please talk from 3 aspects: server-client communication(including APIs), UI/UX design, optimization for performance.

Basically just take your pick of websites (Facebook, Instagram, Reddit, etc.) and think about what sort of components you need to build and how data flow works, and how the API for it should be designed.

Design Amazon comments filtering system. Use UML to design the classes.
started with clarifying the requirements and selecting 3-4 main features to discuss about.
popular social media platform from scratch - authentication, authorization,- optimizing the front-end with pagination techniques supported by the back-end

design and implement a working dropbox like application only using pure javascript/CSS/html, which should support a directory structure with folders, files and ability to add/delete/modify efficiently. They also expect the application to run at Amazon scale.

Assume you are given two APIs List<Person> getFriends(Person); and List<Order> getOrders(Person);. Design a feature like Amazon's recommendation system, except fill it with orders of a person's friends.
Now what if multiple people ordered the same thing, and we want to return the orders from most purchased to least purchased?
Now what if someone purchased multiple of the same item and we only want one copy of that counted?
Now what if we want to extend this to friends of friends?

Design a carousel.
Design a class to implement a list which contains hot selling items from a catalog of given items per seller.
Basic questions on types of HTTP response, how to handle browser inconsistencies, favorite es6 feature and day to day activities routine in my current job.


Resouces: --------------------------------------------------------------------------------------------------
https://github.com/donnemartin/system-design-primer

Technical:
Leetcode:
40-50 medium/easy questions.
Topics covered - Sorting, DFS, BFS, Trie, Object Design, Linked List (single/doubly), etc..
https://www.youtube.com/channel/UCIPzukkCO01wPnMo1DZXIcQ/videos - search for linked list implementation by this guy it's really good for a basic js implementation

System Design:
*** System Design, Youtube videos by Gaurav Sen, TechDummies, Tushar Roy.
Design: Uber, Twitter, Cache, Netflix, etc
Concepts: Distributed System, CDN, Caching, Load Balancer, Heartbeats, Message Queues, Database SQL vs noSQL, Sharding, Storages, Microservices, Hashing, API Gateway, HTTP Protocols etc

Front End:
Frameworks, JS Concepts, OOPs, Design Patterns, Basic Regex Patterns,
David Sharrif Blogs, Tutorials by Mosh
Some good videos:
https://www.youtube.com/user/Fidde12345 - check the front end engineer interview, it sheds light on some good practices.
Practiced creating basic ui eg: carousel, accordion, star pattern, progress bar in both vanilla js and a framework

Behaviour:
Kept 3 Examples handy for Customer Obsession, Ownership, Insist on High Standards, Deliver Result, Disagree and Commit and 1 for others. Basically i had around 25 short stories and whenever I got some free time I would think of my experience for a principle.

Interview Questions to ask: https://github.com/viraptor/reverse-interview - this really helped I kept 2-3 interesting questions for each interviewer based on their role to make sure that the round ends on a good note:P

Overall experience was really good, interviewers were really nice and provided hints in between. The key was to clarify, think out loud and optimize before jumping to solution and explain the interviewer thes decisions made while coding. Also a week before the interview there was a prep call and recruiter gave great pointers


