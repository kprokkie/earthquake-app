https://leetcode.com/problems/word-ladder-ii
https://leetcode.com/problems/best-time-to-buy-and-sell-stock 
Print boundary of the Binary tree
Implement String Compression Algorithm . i.e if string is "aaabbb" output will be a3b3.
Please explain lowest common ancestor concept. Then asked to write code for it and check it
     against test cases.

     Design Elevator system
     evaluate a binary tree.

     Lets say you have two strings: 'the' and 'The cop has a nice little hat.' Write a function that will check each character from first string and count the same in the second string. Return the total count. For example, character 't' occurred 3 times (case sensitive), character 'h' occurred 3 times and character 'e' occurred 3 times in the second string. Total count = 9.  

Show More
Design a game using any language of your choosing where in a person holds a gun and fires at random objects. These objects keep on appearing at random locations and the person can aim in 2D. Once the person hits the object, its health increases (max 100) and if the person misses the target, its health reduces by 10. When the health reaches 0, game over.  
w Less
If you go to amazon.com website, you'll see that there is a section which shows you the top selling items in amazon. Write an algorithm that mimics the same. For example, you have 10 items and each has number of sales increasing randomly per second. Use the right data structure and algorithm to host the top selling item.  