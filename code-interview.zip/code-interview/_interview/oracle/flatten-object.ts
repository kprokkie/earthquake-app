const json = {
    "apple": "ball",
    "foo": {
        "value": "foobar"
    },
    "a": {
        "b": {
            "c": "t"
        }
    }
}

// const op = {
//     "key": "key1",
//     "foo.value": "foorbar"
// }

function flatten(obj) {

    let result = {};

    function helper(parent, obj) { // a 
        Object.keys(obj).forEach(key => { 
            const mykey = parent ? `${parent}.${key}` : key;
            if (typeof obj[key] === 'object') {
            
                    helper(mykey, obj[key]); // (a.b {c:t})
                
            } else {
               
                    result[`${key}`] = obj[key]; // {apple: ball}
            }
        });

    }

    helper(null, obj);
    return result;
}

console.log('Hi');
console.log(flatten(json));

