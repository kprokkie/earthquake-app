function f2() {
    console.log('i m in fn');
}

// f1();
f2();
let f1 = f2;
f1();

function Ninja() {
    this.name = "Ninja";
    return this;
}

var ninjaA = Ninja();
console.log(ninjaA.name);

var ninjaB = new Ninja();
console.log(ninjaB);