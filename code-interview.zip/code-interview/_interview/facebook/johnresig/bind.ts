Function.prototype.bind = function () {
    //console.log(this, arguments);
    var fn = this, args = Array.prototype.slice.call(arguments), object = args.shift();
    return function () {
        return fn.apply(object,
            args.concat(Array.prototype.slice.call(arguments)));
    };
};

let obj  = {
    name: 'Rokkie'
}

function log(time) {
    console.log('Hello ' + this.name + time);
}

let l = log.bind(obj, 'New');
console.log(l());



