const arr = [1, 2, 3, 4, 5, 6];



// Array.prototype.forEachN = Array.prototype.forEach || function (fn) {
    Array.prototype.forEachN = function (fn) {
    for (let i = 0; i < this.length; i++) {
        console.log('change');
        fn(this[i], i, this);
    }
}

arr.forEachN((item, index, arr1) => {
    console.log(item, index, arr1);
})