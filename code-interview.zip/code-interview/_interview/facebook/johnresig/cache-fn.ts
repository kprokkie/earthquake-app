function getElements(name) {
    var results;

    if (getElements.cache[name]) {
        results = getElements.cache[name];
    } else {
        results = [1,2,3,4,5] || document.getElementsByTagName(name);
        getElements.cache[name] = results;
    }

    return results;
}
getElements.cache = {};

console.log("Elements found: ", getElements("pre").length);
console.log("Cache found: ", getElements.cache.pre.length);