// function Person(){}
// Person.prototype.dance = function(){
//     console.log('dance');
// };

function Ninja(){}

// Achieve similar, but non-inheritable, results
Ninja.prototype = Person.prototype;
Ninja.prototype = { dance: Person.prototype.dance };

console.log( (new Ninja()) instanceof Person, "Will fail with bad prototype chain." );

// Only this maintains the prototype chain
Ninja.prototype = new Person();

var ninja = new Ninja();
console.log( ninja instanceof Ninja, "ninja receives functionality from the Ninja prototype" );
console.log( ninja instanceof Person, "... and the Person prototype" );
console.log( ninja instanceof Object, "... and the Object prototype" );
// console.log(ninja.dance());

function Person(){}
Person.prototype.getName = function(){
  return this.name;
};

function Me(){
  this.name = "John Resig";
}
Me.prototype = new Person();

var me = new Me();
console.log( me.hasOwnProperty(Object.keys(me)[0]));
console.log( me.getName(), "A name was set." );