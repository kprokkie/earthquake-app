{
    const arr = [0, -1, 2, -3, 1];
    // distinct 
    // space
    //  [0, -1, 1] [ 2, -3, 1] // ordered 

    function threeSumZero(arr) {
        let len = arr.length;
        let hSet = new Set(arr);
        console.log(hSet);

        for (let i = 0; i < len - 1; i++) {

            // let hSet = new Set();
            for (let j = i + 1; j < len; j++) {
                let rem = - (arr[i] + arr[j]);
                if (hSet.has(rem))
                    console.log([rem, arr[i], arr[j]]);
                else hSet.add(arr[j]);

                console.log('Track: ', arr[i], arr[j], rem, hSet);
            }

        }

    }

    console.log(threeSumZero(arr));

}