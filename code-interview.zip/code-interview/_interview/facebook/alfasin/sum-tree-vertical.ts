{
    const node2 = {
        value: 1,
        left: {
            value: 2,
            left: {
                value: 4,
                left: null,
                right: null
            },
            right: {
                value: 5,
                left: null,
                right: null
            }
        },
        right: {
            value: 3,
            left: {
                value: 6,
                left: null,
                right: null
            },
            right: {
                value: 7,
                left: null,
                right: null
            }
        }
    }

    function sumVerticalTree(root) {

        if (!root) return [0];

        let hash = {};
        let result = [];

        function helper(node, x) {

            // if (!hash[x]) hash[x] = [];
            // hash[x].push(node.value);

            if (!hash[x]) hash[x] = node.value;
            else hash[x] += node.value;

            if (node.left) helper(node.left, x - 1);
            if (node.right) helper(node.right, x + 1);

        }

        helper(root, 0);

        // for (let key in hash) {
        //     console.log(key, hash[key]);
        // }

        for (let key of Object.keys(hash).sort()) {
            result.push(hash[key]);
        }

        return result;

    }

    console.log(sumVerticalTree(node2));
}