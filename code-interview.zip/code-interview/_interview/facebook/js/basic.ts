(function () {
    var a = b = 5;
})();

console.log(b);

String.prototype.repeatify = String.prototype.repeatify || function (times) {

    let count = arguments[0] || times;

    let str = '';
    for (let i = 0; i < count; i++) {
        str += this;
    }
    return str;

    console.log(this, ...arguments, times);

}

console.log('hello'.repeatify(3));

function test() {
    console.log(a);
    console.log(foo());

    var a = 1;
    function foo() {
        return 2;
    }
}

test();

var fullname = 'John Doe';
var obj = {
   fullname: 'Colin Ihrig',
   prop: {
      fullname: 'Aurelio De Rosa',
      getFullname: function() { 
         return this.fullname;
      }
   }
};

console.log(obj.prop.getFullname());

var test = obj.prop.getFullname;

console.log(test());