{
    // Given nested array calculate the depth sum and provide time and space complexity.
    // Input: [1, 2, [4, 5, [7], 8], 9]
    // Output: 1 + 2 + 2*(4 + 5 + 3*7 + 8) + 9 = 88 

    // const arr = [1, 2, [4, 5, [7], 8], 9];
    // const arr = [1, 2, [3, 4, [5, [6], 7], 8], 9, 10];
    // const arr = [1, 2, [5], 6, 10];
    const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

    function nestedArraySum(arr) {

        let sum = 0;
        function helper(arr, level, factor) {
            console.log('------------', level, factor);
            for (let i = 0; i < arr.length; i++) {
                if (Array.isArray(arr[i])) {
                    helper(arr[i], ++level, level * factor);
                } else {
                    sum += factor * arr[i];
                }
            }
        }
 
        helper(arr, 1, 1);
        return sum;
    }

    console.log(nestedArraySum(arr));

}