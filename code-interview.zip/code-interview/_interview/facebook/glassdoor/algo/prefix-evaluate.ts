{
    const expr = '-+7*45+20'

    class Node {
        constructor(value) {
            this.value = value;
            this.left = this.right = null;
        }
    }

    function isOperator(operator) {
        if (operator == '+' ||
            operator == '-' ||
            operator == '*' ||
            operator == '/' ||
            operator == '^') return true;
        return false;
    }

    function inorder(root) {
        let exp = '';
        function helper(node) {
            if (!root) return;
            if (node.left) helper(node.left);
            exp += node.value;
            if (node.right) helper(node.right);
        }
        helper(root);
        return exp;
    }

    function constructTreeFromPrefix(expr) {

        let stack = [];

        for (let i = expr.length - 1; i >= 0; i--) {

            if (!isOperator(expr[i])) {
                const node = new Node(expr[i]);
                stack.push(node); // 0 2
            } else {
                let l = stack.pop(); // 2
                let r = stack.pop(); // 0

                let node = new Node(expr[i]);
                node.left = l;
                node.right = r;

                stack.push(node);
            }
        }

        return stack.pop();
    }

    function valueFromPrefix(expr) {

        let stack = [];

        for (let i = expr.length - 1; i >= 0; i--) {

            if (!isOperator(expr[i])) {
                // const node = new Node(expr[i]);
                // stack.push(node); // 0 2
                stack.push(+expr[i]);
            } else {
                let l = stack.pop(); // 2
                let r = stack.pop(); // 0

                // let node = new Node(expr[i]);
                // node.left = l;
                // node.right = r;

                stack.push(eval(`${l}${expr[i]}${r}`));
            }
        }

        return stack.pop();
    }

    console.log(inorder(constructTreeFromPrefix(expr)));
    console.log(valueFromPrefix(expr));


}