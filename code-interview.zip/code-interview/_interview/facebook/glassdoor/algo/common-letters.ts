{
    const string1 = 'geeks',
        string2 = 'forgeeks';


    function getHash(s) {

    }

    function commonLetters(s1, s2) {

        let map = new Map();

        for (let char of s1) {
            if (!map.has(char))
                map.set(char, 1);
            else
                map.set(char, map.get(char) + 1);
        }

        console.log(map);

        let str = '';
        for (let char of s2) {
            if (map.has(char)) {
                str += char;
                map.set(char, map.get(char) - 1)
                if (!map.get(char)) map.delete(char);
            }
        }

        console.log([...str].sort().join(''));




    }

    commonLetters(string1, string2);
    commonLetters("geeksforgeeks", "practiceforgeeks");

}