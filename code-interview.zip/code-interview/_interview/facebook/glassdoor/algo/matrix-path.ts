{
    const m = [
        [0, 3, 0, 1],
        [3, 0, 3, 3],
        [2, 3, 3, 3],
        [0, 3, 3, 3]
    ];

    function matrixPath(m) {

        


    }

    matrixPath(m);

}

