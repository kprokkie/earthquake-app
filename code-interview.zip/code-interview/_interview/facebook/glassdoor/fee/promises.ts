const promise = (delay) => new Promise((resolve, reject) => {
    setTimeout(() => resolve('Hello World!'), 2000);
});

console.log(promise);

promise(5000).then(
    (data) => {console.log(data); console.log(promise)},
    (err) =>{ console.log(err); console.log(promise)}
);

// or 

promise.then((data) => console.log(data))
    .catch((err) => console.log(err));
