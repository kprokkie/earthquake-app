
{
    let arr = [1, 2, 3, 4, 5];

    const it = arr[Symbol.iterator]();

    console.log(it);
    let data = it.next();
    console.log(data);
    // console.log(it.next());

    // or
    for (let val of it) {
        console.log(val);
    }

}

// -------------------------
// Observables are lazy; we don’t invoke the function yet just saving a reference.
class Observable {

    constructor(functionThatThrowsValues) {
        this._functionThatThrowsValues = functionThatThrowsValues;
    }

    subscribe(observer) {
        return this._functionThatThrowsValues(observer);
    }

    static fromEvent(element, event) {
        return new Observable(observer => {
            const handler = (e) => observer.next(e);
            element.addEventListener(event, handler);

            return () => {
                element.removeEventListener(event, handler);
            };

        });
    }

    static fromArray(array) {
        return new Observable(observer => {
          array.forEach(val => observer.next(val));
          observer.complete();
       });
     }

    map(projectionFunction) {
        return new Observable(observer => {
            return this.subscribe({
                next(val) { observer.next(projectionFunction(val)) },
                error(e) { observer.error(e) },
                complete() { observer.complete() }
            });
        });
    }

}

let fakeAsyncData$ = new Observable(observer => {
    setTimeout(() => {
        observer.next('New data is coming');
        observer.complete();
    }, 2000);
});

fakeAsyncData$.subscribe({
    next(val) { console.log(val) },
    error(e) { console.log(e) },
    complete() { console.log('complete') }
});

let array$ = Observable.fromArray([1, 2, 3]);
array$.subscribe({
    next(val) { console.log(val) },
    error(e) { console.log(e) },
    complete() { console.log('complete') }
});

// Let’s see how we can create the map method.
fakeAsyncData$.map(val => `New value ${val}`).subscribe({
    next(val) { console.log(val) },
    error(e) { console.log(e) },
    complete() { console.log('complete') }
});

// var button = document.getElementById('button');
// let clicks$ = Observable.fromEvent(button, 'click')
//     .map(e => `${e.pageX}px`);
// let unsubscribe = clicks$.subscribe({
//     next(val) { console.log(val) },
//     error(e) { console.log(e) },
//     complete() { console.log('complete') }
// });

