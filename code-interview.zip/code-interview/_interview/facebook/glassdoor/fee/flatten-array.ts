{ // block scope

    // const arr = [1, 2, 3, [4, 5, 6], 7, 8];
    // const arr = [1, 2, 3, [4, 5, 6], 7, 8, [9, [10, 11, [12, 13]]], 14];
    const arr = [1, true, 3, [4, null, 6], { name: 'KP' }, 8, undefined, 10];

    // O(n^2)
    const flattenArrayIterative = (arr) => {
        // edge case
        if (!arr || !arr.length) return [];

        let resArr = [];
        while (arr.length) { // O(n)
            let next = arr.shift(); // O(n)
            if (Array.isArray(next)) {
                arr = next.concat(arr); // O(n)
            } else if (next != undefined) {
                resArr.push(next); // O(1)
            }
        }
        return resArr;
    }

    console.log(flattenArrayIterative([...arr]));

    const flattenArrayRecursive = (arr) => {
        // edge case
        if (!arr || !arr.length) return [];

        let resArr = [];
        flattenHelper(arr, resArr);
        return resArr;
    }

    const flattenHelper = (currArr, resArr) => {
        currArr.forEach(next => {
            if (Array.isArray(next)) {
                flattenHelper(next, resArr);
            } else if (next !== undefined && next !== null) {
                resArr.push(next)
            }
        });
    }

    console.log(flattenArrayRecursive([...arr]));
}