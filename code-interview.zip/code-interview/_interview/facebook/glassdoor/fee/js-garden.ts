function Foo() {

}

Foo.prototype.method = function () {
    console.log(this);
    let context = this;
    function test() {
        // console.log(this);
        console.log(context);
    }
    test();
}

// or ES5 way 
Foo.prototype.method2 = function () {
    var test = function () {
        console.log(this);
    }.bind(this);
    test();
}

// or ES6 way
Foo.prototype.method3 = function () {
    let test = () => {
        console.log(this);
    };
    test();
}

let obj = new Foo();
// obj.method2();
// obj.method3();

// protypical inheritence
function Foo1() { }
Foo1.prototype.method = function () { };

function Bar1() { }
Bar1.prototype = Foo1.prototype;

new Bar1().method();
//------------------------------------------------------------------------
// for (var i = 0; i < 10; i++) {
//     setTimeout(function () {
//         console.log(i);
//     }, 1000);
// }

for (var i = 0; i < 10; i++) {
    setTimeout(function (e) {
        console.log(e);
    }, 1000, i);
}

// for (var i = 0; i < 10; i++) {
//     (function (e) {
//         setTimeout(function () {
//             console.log(e);
//         }, 1000);
//     })(i);
// }

// for (var i = 0; i < 10; i++) {
//     helper(i);
// }

// function helper(i) {
//     setTimeout(function () {
//         console.log(i);
//     }, 1000);
// }


function Person(name) {
    this.name = name;
}

Person.prototype.logName = function() {
    console.log(this.name);
};

var sean = new Person('Rokkie');
sean.logName();

function Car() {
    return 'ford';
}
new Car(); // a new object, not 'ford'

function Person() {
    this.someValue = 2;

    return {
        name: 'Charles'
    };
}
new Person(); // the returned object ({name:'Charles'}), not including someValue

// ------------------------------------------------------------------

// Factories
// In order to be able to omit the new keyword, 
// the constructor function has to explicitly return a value.

function Robot() {
    var color = 'gray';
    return {
        getColor: function() {
            return color;
        }
    }
}

new Robot();
Robot();

// In order to create a new object, 
// one should rather use a factory and construct a new object inside of that factory.

function CarFactory() {
    var car = {};
    car.owner = 'nobody';

    var milesPerGallon = 2;

    car.setOwner = function(newOwner) {
        this.owner = newOwner;
    }

    car.getMPG = function() {
        return milesPerGallon;
    }

    return car;
}