// Given a grid of characters output a decoded message. 
// The message for the following would be IROCKA. 
// (diagonally down right and diagonally up right if you can't go further .. you continue doing this)

const m = [
    ['I', 'B', 'C', 'A', 'K', 'L', 'A'],
    ['D', 'R', 'F', 'C', 'E', 'E', 'A'],
    ['G', 'H', 'O', 'E', 'A', 'U', 'D']
];


function decodeMessage(m) {

    let row = m.length;
    let col = m[0].length;

    // console.log(row, col);

    let i = 0, j = 0
    let str = '';
    let iFlag = true;

    while (j < col && i >= 0 && i < row) {

        str += m[i][j];

        if (i == row - 1) iFlag = false;
        if (i == 0) iFlag = true;

        iFlag ? i++ : i--;
        j++;
    } 
    return str;
}

console.log(decodeMessage(m));

