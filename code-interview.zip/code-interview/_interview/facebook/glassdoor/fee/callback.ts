// getSum is a function that accepts callback into a function returning a <callback> function
function getSum(num1, num2, callback) {
    console.log('fncall', num1, num2, callback);
    if (!num1 || !num2)
        return callback(null, new Error('Missing Arguments'));
    return callback(num1 + num2, null);
}

function callback (res, err) {
    if (err) console.log('Error: ', err);
    else console.log('Result: ', res);
}

getSum(12, 56, callback);

// getSum(12, 56, (res, err) => {
//     if (err) console.log('Error: ', err);
//     else console.log('Result: ', res);
// });

function getSum1(num1, num2) {
    if (!num1 || !num2)
        throw 'Missing Arguments';
    throw num1 + num2;
}

// const fn = (res, err) => console.log(res, err);
// const result = getSum(12, 12, fn);
// console.log(result);

// ------------------------------------------------------------
// What is Promisification?
// Promisification means transformation. 
// It’s a conversion of a function that accepts a callback into a function returning a promise.

// conversion of a (function that accepts a callback into a function) then returning a promise

// Using Node.js's util.promisify():
// ------------------------------------
// const { promisify } = require('util')
// const getSumPromise = promisify(getSum) // step 1
// getSumPromise(1, 1) // step 2
// .then(result => {
//   console.log(result)
// })
// .catch(err =>{
//   console.log(err);
// })

const myPromisify = (fn) => {
    // return (a, b) => {

    // }
    // we are spreading arguments because we don’t know how many arguments the original function has
    return (...args) => {
        console.log(args);
        // return a promise
        return new Promise((resolve, reject) => {
            function callback(res, err) {
                if (err) reject(err);
                else resolve(res);
            }
            args.push(callback);
            console.log(args);
            fn.apply(this, args);
        })
    }
}

const getSumPromise = myPromisify(getSum);
const p = getSumPromise(12, 34);

p.then((res) => console.log(res))
    .catch((err) => console.log(err));

