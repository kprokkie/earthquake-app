let bool = typeof new Promise((resolve, reject) => { }) === 'object';
// console.log(bool);

{
    // let person = {
    //     name: 'John Doe',
    //     getName: function () {
    //         console.log(this.name);
    //     }
    // };

    // setTimeout(person.getName, 1000);

    // let f = person.getName;
    // setTimeout(f, 1000); // lost person context

    // setTimeout(function () {
    //     person.getName()
    // }, 1000);

    // let f1 = person.getName.bind(person);
    // setTimeout(f1, 1000);

    // Promise.then().catch()
}

class PromiseScratch {

    promiseChain;
    handleError;

    constructor(executorFn) {
        console.log('executorFn: ', executorFn);

        this.promiseChain = []; // array
        this.handleError = () => { }; // error fn

        this.onResolve = this.onResolve.bind(this);
        this.onReject = this.onReject.bind(this);

        console.log('this.onResolve: ', this.onResolve);
        console.log('this.onReject: ', this.onReject);

        executorFn(this.onResolve, this.onReject);
    }

    // public methods ------------------------------------

    then(onResolve) {
        console.log('then: ', onResolve);
        this.promiseChain.push(onResolve);
        return this;
    }

    catch(handleError) {
        console.log('catch: ', handleError);
        this.handleError = handleError;
        return this;
    }

    // internal methods -----------------------------------

    onResolve(res) {
        console.log('onResolve: ', res);
        let val = res;
        try {
            this.promiseChain.forEach((nextFn) => {
                val = nextFn(val);
            });

        } catch (err) {
            this.promiseChain = [];
            this.onReject(err);
        }
    }

    onReject(err) {
        console.log('onReject: ', err);
        this.handleError(err);
    }

} 

const p1 = new PromiseScratch((resolve, reject) => {
    setTimeout(() => {
        if (Math.random() > .05) resolve({ data: { user: 'Rokkie' } });
        else reject({ error: 'Not Found' });
    }, 5000);
});

console.log('-------------------------------');
console.log('object: ', p1);
console.log('-------------------------------');

p1.then(({ data }) => {
    console.log(data);
    return data;
}).then(({ user }) => {
    console.log(user);
}).catch((err) => {
    console.log(err);
});