// Given input:

// could be potentially more than 3 keys in the object above
const items = [
    { color: 'red', type: 'tv', age: 18 },
    { color: 'silver', type: 'phone', age: 20 },
    { color: 'pink', type: 'mobile', age: 40 }
    // ... N items M properties
];

const excludes = [
    { k: 'color', v: 'silver' },
    { k: 'type', v: 'tv' },
    // ... X exculdes Y properties
];

function excludeItems(items, excludes) { 
    excludes.forEach(pair => { // XN
        // items = items.filter(item => item[pair.k] === item[pair.v]); // wrong statement
        items = items.filter(item => item[pair.k] !== pair.v);
    });
    return items;
}

console.log(excludeItems(items, excludes));

function excludeItemsOptimized([...items], [...excludes]) {

    let exludesHash = {}; // S: O(n)
    excludes.forEach((pair) => exludesHash[pair.k] = pair.v); // T: O(n)
    console.log(exludesHash);

}

console.log(excludeItemsOptimized(items, excludes));

// array of N elements 
// {property1: value1; property2: value2;...;propertyX: valueX}
// array of M elements 
// {"property: value"}
// write an algorithm to remove every element in the N length array 
// that has a "property: value" pair in the M length array.

const arr1 = [
    { car: "honda", name: "John" },
    { car: "bmw", name: "Johnny", os: "ios" },
    { car: "toyota", name: "JohnX", os: "android" },
];

const arr2 = [
    { car: "honda" },
    { os: "android" }
];

function filterKey(arr1, arr2) {
    // method 1
    arr2.forEach((x2) => {
        console.log(x2);
        let res = arr1.filter((x1) => x1.car === x2.car || x1.os === x2.os);
        console.log(res);
    });
    // return arr1;

}

console.log(filterKey(arr1, arr2));  


const emitter = new Emitter();

// 1. Support subscribing to events.
const sub = emitter.subscribe('event_name', callback);
const sub2 = emitter.subscribe('event_name', callback2);
const sub3 = emitter.subscribe('event_name', callback);

// 2. Support emitting events.
// This particular example should lead to the `callback` above being invoked with `foo` and `bar` as parameters.
emitter.emit('event_name', 'foo', 'bar');

// 3. Support unsubscribing existing subscriptions by releasing them.
sub3.release(); // `sub` is the reference returned by `subscribe` above


class Emitter {
  
  constructor() {
    this.events = {};
  }
  
  subscribe(eventName, callbackFn) {
    this.events[eventName] = this.events[eventName] || [];
    this.events[eventName].push(callbackFn);
    
    return {
      // release: function () {
      //   const idx = this.events[eventName].indexOf(callbackFn);
      //   if (idx === -1) return;
      //     this.events[eventName].splice(idx, 1);
      // }
      release: () => delete this.events[eventName];
    }
    
  }
  
  
  emit(eventName, ...params) {
    if (this.eventsName[eventName]) {
      this.events[eventName].forEach((fn) => fn.apply(null, params));
    } else return;
  }
  
}


//////////

items = [
  {type: 'phone', name: 'iPhone', color: 'gold'},
  {type: 'laptop', name: 'Chromebook', color: 'gray'},
  // ...
] // N

excludes = [
  {k: 'color', v: 'gold'},
  {k: 'color', v: 'silver'},
  {k: 'type', v: 'tv'},
  // ...
] // M

function applyFilters(items, excludes) { /// O(NM)
  excludes.forEach(function(pair) { // O(M)
    items = items.filter((item) => item[pair.k] !== pair.v); // O(N)
  });
  return items;
}

function applyFilters(item, exculdes) {
  
    let map = new Map();
    exculdes.forEach(pair => map.add(pair.k, new Set(pair.v)));
  
    // map = { color: [gold, silver], type: [tv]}
  
  
  
  
}










