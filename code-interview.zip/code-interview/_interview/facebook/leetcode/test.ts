const s = 'Hi my name is Bob';

let str = s.split(' ');

let avg = 0;
let sum = 0;
for (let word of str) {
    sum += word.length;
}

console.log(sum);
console.log(sum/str.length)