class BSTIterator {

    sortedArr;
    index;
    flag;
    steps;
    k;

    constructor(root, k) {
        this.index = -1;
        this.sortedArr = [];
        this.steps = k;
        this.k = k;

        this.inorderTraversal(root);
    }

    // iterating each node // O(n)
    inorderTraversal(node) {
        if (!node) return;

        if (node.left) this.inorderTraversal(node.left);
        this.sortedArr.push(node.value);
        if (node.right) this.inorderTraversal(node.right);
    }

    next() { // O(1)
        return this.sortedArr[++this.index];
    }

    hasNext() { // O(1)
        this.steps = this.k;
        return this.sortedArr.length - this.index - 1 > 0;
    }

    prev() {
        this.steps--;
        if (this.index > 0 && this.steps > -1) return this.sortedArr[--this.index]
        else return null;
    }

    hasPrev() {
        if (this.index > 0) return !!this.steps;
        else return false;
    }
}

const node = {
    value: 10,
    left: {
        value: 6,
        left: {
            value: 3,
            left: null,
            right: null
        },
        right: {
            value: 8,
            left: null,
            right: null
        }
    },
    right: {
        value: 15,
        left: null,
        right: {
            value: 20,
            left: null,
            right: null
        }
    }
};

const bst = new BSTIterator(node, 7);
console.log(bst.hasPrev());

console.log(bst.prev());
console.log(bst.next());
console.log(bst.next());
console.log(bst.hasNext());
console.log(bst.next());
console.log(bst.next());

console.log(bst.hasPrev());

console.log(bst.prev());
console.log(bst.hasPrev());
console.log(bst.next());
console.log(bst.next());

console.log(bst.next());
console.log(bst.hasNext());
// 
console.log('complete');
console.log(bst.hasPrev());
console.log(bst.prev());
console.log(bst.hasPrev());
console.log(bst.prev());
console.log(bst.hasPrev());
console.log(bst.prev());
console.log(bst.hasPrev());
console.log(bst.prev());
console.log(bst.hasPrev());
console.log(bst.prev());
console.log(bst.hasPrev());
console.log(bst.prev());
console.log(bst.hasPrev());
console.log(bst.prev());
console.log(bst.hasPrev());
console.log(bst.prev());

console.log('deleted');
console.log(bst.hasNext());
console.log(bst.next());



