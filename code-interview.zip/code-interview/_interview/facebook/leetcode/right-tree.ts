{
    const node = {
        v: 1,
        l: {
            v: 2,
            l: {
                v: 4,
                l: null,
                r: {
                    v: 7,
                    l: null,
                    r: {
                        v: 9,
                        l: null,
                        r: {
                            v: 10,
                            l: null,
                            r: null
                        }
                    }
                }
            },
            r: {
                v: 5,
                l: null,
                r: null
            }
        },
        r: {
            v: 3,
            l: null,
            r: {
                v: 6,
                l: {
                    v: 8,
                    l: null,
                    r: null
                },
                r: null
            }
        }
    }

    const node2 = {
        v: 1,
        l: {
            v: 2,
            l: null,
            r: {
                v: 5,
                l: null,
                r: null
            }
        },
        r: {
            v: 3,
            l: null,
            r: {
                v: 4,
                l: null,
                r: null
            }
        }
    }

    var rightSideView = function (root) {

        if (!root) return [];

        let q = [];
        let result = [];

        q.push(root);

        while (q.length) {

            let topNode = q[q.length - 1];
            result.push(topNode.v);

            let size = q.length;
            for (let i = 0; i < size; i++) {
                let node = q.shift();
                if (node.l) q.push(node.l);
                if (node.r) q.push(node.r);
            }
        }

        return result;

    };

    console.log(rightSideView(node2));
}