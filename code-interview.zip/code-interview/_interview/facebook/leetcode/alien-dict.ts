function verifyAlien (words, order) {
    
}