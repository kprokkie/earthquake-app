/**
 * @param {number[]} nums
 * @param {number} k
 * @return {number}
 */
var subarraySum = function (nums, k) {

    if (nums.length < k) return 0;

    let sum = 0;

    // for (let i = 0; i < k; i++) {
    //     sum += nums[i];
    // }

    sum = nums[0];

    for (let i = 0; i < nums.length; i++) {

        if (sum === k) {

        }
    }


};

const nums = [1, 1, 1], k = 2; // Output: 2
console.log(subarraySum(nums, k));

// var subarraySum = function (nums, k) {
    
//     let counter = 0;

//     while (nums.length) {    
//          nums.reduce((acc, nextNum) => {
//             acc += nextNum;
//             if (acc == k) {
//                 counter++;                
//             }
//             return acc;
//         }, 0);
//         nums.shift();
//     }
    
//     return counter;
// };