{
    const m = [
        [0, 0, 0, 1],
        [0, 0, 1, 1],
        [0, 0, 1, 1],
        [0, 0, 0, 0]
    ];


    function lowCol(m) {
        let i = m.length - 1;
        let j = m[0].length - 1;

        while (i >= 0 && j >= 0) {
            if (!m[i][j]) i--;
            else j--;
        }

        console.log(i, j);

        return j === m[0].length - 1 ? -1: j + 1;
    }

    console.log(lowCol(m));
}