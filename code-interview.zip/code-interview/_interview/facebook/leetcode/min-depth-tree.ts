/**
 * Definition for a binary tree node.
 * function TreeNode(val, left, right) {
 *     this.val = (val===undefined ? 0 : val)
 *     this.left = (left===undefined ? null : left)
 *     this.right = (right===undefined ? null : right)
 * }
 */
/**
 * @param {TreeNode} root
 * @return {number}
 */
var minDepth = function (root) {

    function helper(node) {
        if (!node) return 0; 
        if (!node.left && !node.right) return 1;
        if (!node.left) return helper(node.right) + 1;
        if (!node.right) return helper(node.left) + 1;
        return Math.min(helper(node.left), helper(node.right)) + 1;
    }

    return helper(root);

};

const node1 = {
    value: 10,
    left: {
        value: 6,
        left: {
            value: 3,
            left: null,
            right: null
        },
        right: {
            value: 8,
            left: null,
            right: null
        }
    },
    right: {
        value: 15,
        left: null,
        right: {
            value: 20,
            left: null,
            right: null
        }
    }
};

const node2 = {
    value: 1,
    left: {
        value: 2,
        left: {
            value: 3,
            left: {
                value: 4,
                left: {
                    value: 5,
                    left: null,
                    right: null
                },
                right: null
            },
            right: null
        },
        right: null
    },
    right: null
};
console.log(minDepth(node2));