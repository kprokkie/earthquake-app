
var minAddToMakeValid = function(S) {
    let hash = {
        ')': '('
    }
    
    let min = 0;
    let stack = [];
    
    for (let paran of S) {
        if (!hash[paran]) {
            stack.push(paran);
        }
        else {
            let p = stack.pop();
            if (!p && p !== hash[paran]) min++;
        }
    }
        
    return stack.length + min;
};

var minRemoveToMakeValid = function (s1) {

    let s = s1.split('');
    let len = s.length;

    let stack = [];

    for (let i = 0; i < len; i++) {
        if (s[i] === '(')
            stack.push(i);
        else if (s[i] === ')') {
 
            if (stack.length) stack.pop();
            else s[i] = '';
        }
    }

    console.log(stack);

    for (let i of stack) s[i] = '';

    return s.join('');
};

const s = "lee(t(c)o)de)";
console.log(minRemoveToMakeValid(s));