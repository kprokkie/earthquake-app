/**
 * Definition for a binary tree node.
 * function TreeNode(val, left, right) {
 *     this.val = (val===undefined ? 0 : val)
 *     this.left = (left===undefined ? null : left)
 *     this.right = (right===undefined ? null : right)
 * }
 */
/**
 * @param {TreeNode} root
 * @return {number[]}
 */
var largestValues = function(root) {
    if (!root) return [];
    
    let result = [];
    
    let q = [];
    q.push(root);
    
    while (q.length) {
        
        let size = q.length; 
        let max = Number.MIN_SAFE_INTEGER;
        
        for (let i = 0; i < size; i++) {
            let node = q.shift();    
            if (node.left) q.push(node.left);
            if (node.right) q.push(node.right);
            
            max = Math.max(max, node.val);
        }
        result.push(max);
    }
    
    return result;
};