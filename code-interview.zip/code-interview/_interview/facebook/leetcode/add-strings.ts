function addStrings(num1, num2) {

    let i = num1.length - 1;
    let j = num2.length - 1;

    let carry = 0;
    let result = '';

    while (i >= 0 || j >= 0) {
        let sum = carry;

        if (i >= 0) sum += +num1[i];
        if (j >= 0) sum += +num2[j];

        result = (sum % 10) + result;
        carry = Math.floor(sum / 10); 

        i--;
        j--;
    }

    if (carry) result = carry + result;

    return result;
}

console.log(addStrings('4251', '231'));
console.log(addStrings('4251', '23232341'));
console.log(addStrings('499999999999999999999999999999999999999', '232342342424234242'));