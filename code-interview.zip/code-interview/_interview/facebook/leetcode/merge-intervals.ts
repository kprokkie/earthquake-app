/**
 * @param {number[][]} intervals
 * @return {number[][]}
 */
var merge = function (intervals) {
    if (!intervals.length) return [];

    intervals.sort((a, b) => a[0] - b[0] || a[1] - b[1]);

    let result = [];
    let buffer = intervals[0];
    let c = 0;
    for (let i = 1; i < intervals.length; i++) {
        if (buffer[1] >= intervals[i][0]) {
            c++;
            buffer = [buffer[0], Math.max(buffer[1], intervals[i][1])];
        } else {
            result.push(buffer);
            buffer = intervals[i];
        }
    }

    result.push(buffer);
    console.log(c);
    return result;
};

// const intervals = [[15, 18], [1, 3], [2, 6], [8, 10], [1, 2]];
// const intervals = [[15, 18], [1, 3], [2, 6], [8, 10]];
// const intervals = [[1, 4], [2, 3]];
//const intervals = [[1, 10], [2, 6], [9, 12], [14, 16], [16, 17]];
const intervals = [[0, 30], [5, 20], [15, 25]];
console.log(merge(intervals)); // union or merge

