const m = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];

/**
* @param {number[][]} matrix
* @return {number[]}
*/
var findDiagonalOrder = function (matrix) {
     
    let col = matrix[0].length - 1;

    for (let j = 0; j < col; j++) {
        for (let i = 0, k = j; i <= j; i++, k--) {
            
        }
    }

};

console.log(findDiagonalOrder(m));