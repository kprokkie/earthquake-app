// Input: list1 = [5, 1, 2, 4], list2 = [4, 6, 3], list3 = [9, 0, 7]
// Output:
// next(); // 0
// next(); // 1
// next(); // 2
// next(); // 3
// next(); // 4
// next(); // 4
// next(); // 5
// next(); // 6
// next(); // 7
// next(); // 7

class SortedIterator {


    constructor(a1, a2, a3) {
        
    }

    

}