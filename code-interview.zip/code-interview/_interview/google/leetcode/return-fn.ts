// Given a function return a function that executed original function 1 second later.

function foo () {
    console.log('In Foo');
    return function () {
        console.log('Im in');
        setTimeout(foo, 1000);
    }
}

const bar = foo();
bar();  